package com.example.wiredanc

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Bundle
import android.widget.Button
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {

    companion object {
        init {
            System.loadLibrary("anc_engine")
        }
    }

    private external fun startAncEngine(inputDeviceId: Int, outputDeviceId: Int): Boolean
    private external fun stopAncEngine()
    private external fun setAncGain(gain: Float)
    private external fun setFilterAlpha(alpha: Float)

    private var isAncActive = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val statusText = findViewById<TextView>(R.id.tvStatus)
        val toggleBtn = findViewById<Button>(R.id.btnToggleAnc)
        val gainSlider = findViewById<SeekBar>(R.id.seekGain)
        val gainLabel = findViewById<TextView>(R.id.tvGainLabel)
        val modeGroup = findViewById<RadioGroup>(R.id.rgMode)

        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 101)

        gainSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                gainLabel.text = "Anti-Noise Gain: $progress%"
                setAncGain(progress / 100f)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        modeGroup.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.rbFanMode -> setFilterAlpha(0.12f)
                R.id.rbTrafficMode -> setFilterAlpha(0.28f)
            }
        }

        toggleBtn.setOnClickListener {
            if (!isAncActive) {
                val (inId, outId) = getWiredHeadsetDeviceIds()
                if (inId == -1 || outId == -1) {
                    Toast.makeText(this, "Pehle Mic wala Wired Earphone connect karein!", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    val started = startAncEngine(inId, outId)
                    if (started) {
                        isAncActive = true
                        toggleBtn.text = "STOP ANC"
                        statusText.text = "ANC Active (Wired Headset Mic)"
                    } else {
                        Toast.makeText(this, "Audio engine start nahi ho paya", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 101)
                }
            } else {
                stopAncEngine()
                isAncActive = false
                toggleBtn.text = "START ANC"
                statusText.text = "ANC Off"
            }
        }
    }

    private fun getWiredHeadsetDeviceIds(): Pair<Int, Int> {
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val inputDevices = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS)
        val outputDevices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)

        val wiredMic = inputDevices.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET || it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }
        val wiredSpeaker = outputDevices.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET || it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }

        return Pair(wiredMic?.id ?: -1, wiredSpeaker?.id ?: -1)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isAncActive) stopAncEngine()
    }
}
