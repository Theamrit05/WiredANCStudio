#include <jni.h>
#include <oboe/Oboe.h>
#include <cmath>
#include <atomic>

using namespace oboe;

class AncEngine : public AudioStreamDataCallback {
public:
    std::atomic<float> ancGain{0.5f};
    std::atomic<float> lowPassAlpha{0.15f};
    std::atomic<bool> isRunning{false};

    bool start(int32_t inputDeviceId, int32_t outputDeviceId) {
        AudioStreamBuilder inBuilder;
        inBuilder.setDirection(Direction::Input)
                ->setPerformanceMode(PerformanceMode::LowLatency)
                ->setSharingMode(SharingMode::Exclusive)
                ->setFormat(AudioFormat::Float)
                ->setChannelCount(ChannelCount::Mono)
                ->setDeviceId(inputDeviceId)
                ->setInputPreset(InputPreset::Unprocessed);

        if (inBuilder.openStream(mInputStream) != Result::OK) return false;

        AudioStreamBuilder outBuilder;
        outBuilder.setDirection(Direction::Output)
                ->setPerformanceMode(PerformanceMode::LowLatency)
                ->setSharingMode(SharingMode::Exclusive)
                ->setFormat(AudioFormat::Float)
                ->setChannelCount(ChannelCount::Mono)
                ->setDeviceId(outputDeviceId)
                ->setSampleRate(mInputStream->getSampleRate())
                ->setDataCallback(this);

        if (outBuilder.openStream(mOutputStream) != Result::OK) {
            mInputStream->close();
            return false;
        }

        mFilteredSample = 0.0f;
        mInputStream->requestStart();
        mOutputStream->requestStart();
        isRunning = true;
        return true;
    }

    void stop() {
        isRunning = false;
        if (mOutputStream) {
            mOutputStream->requestStop();
            mOutputStream->close();
            mOutputStream.reset();
        }
        if (mInputStream) {
            mInputStream->requestStop();
            mInputStream->close();
            mInputStream.reset();
        }
    }

    DataCallbackResult onAudioReady(AudioStream *outStream, void *audioData, int32_t numFrames) override {
        auto *output = static_cast<float *>(audioData);
        float inputBuffer[numFrames];

        auto result = mInputStream->read(inputBuffer, numFrames, 0);
        int32_t framesRead = result ? result.value() : 0;

        float gain = ancGain.load();
        float alpha = lowPassAlpha.load();

        for (int32_t i = 0; i < numFrames; ++i) {
            if (i < framesRead) {
                mFilteredSample = mFilteredSample + alpha * (inputBuffer[i] - mFilteredSample);
                float antiNoise = -mFilteredSample * gain;

                if (antiNoise > 0.8f) antiNoise = 0.8f;
                if (antiNoise < -0.8f) antiNoise = -0.8f;

                output[i] = antiNoise;
            } else {
                output[i] = 0.0f;
            }
        }
        return DataCallbackResult::Continue;
    }

private:
    std::shared_ptr<AudioStream> mInputStream;
    std::shared_ptr<AudioStream> mOutputStream;
    float mFilteredSample = 0.0f;
};

static AncEngine engine;

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_wiredanc_MainActivity_startAncEngine(JNIEnv *env, jobject, jint inId, jint outId) {
    return engine.start(inId, outId);
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_wiredanc_MainActivity_stopAncEngine(JNIEnv *env, jobject) {
    engine.stop();
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_wiredanc_MainActivity_setAncGain(JNIEnv *env, jobject, jfloat gain) {
    engine.ancGain.store(gain);
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_wiredanc_MainActivity_setFilterAlpha(JNIEnv *env, jobject, jfloat alpha) {
    engine.lowPassAlpha.store(alpha);
}
