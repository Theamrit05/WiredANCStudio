cmake_minimum_required(VERSION 3.22.1)
project("anc_engine")

find_package(oboe REQUIRED CONFIG)

add_library(anc_engine SHARED native-lib.cpp)

target_link_libraries(anc_engine
        oboe::oboe
        android
        log)
