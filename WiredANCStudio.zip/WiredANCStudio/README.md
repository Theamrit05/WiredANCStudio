# Wired ANC Studio

Real-time Active Noise Cancellation Android application using Wired Headset Mic + C++ Oboe Low-Latency Audio Engine.

## Direct Deployment Steps:
1. Extract `WiredANCStudio.zip`.
2. Open **Android Studio** -> **Open** -> Select the `WiredANCStudio` folder.
3. Let Gradle sync and download `com.google.oboe:oboe:1.8.0` automatically.
4. Connect your **Oppo A6s 5G** (or any Android phone) via USB with **USB Debugging** enabled.
5. Plug in a wired earphone with a built-in microphone.
6. Click **Run (▶)** in Android Studio to install and deploy directly to your phone.
